import React from 'react'

export default function EmailSettings() {
  return (
    <div>
      Emailsettings
    </div>
  )
}
