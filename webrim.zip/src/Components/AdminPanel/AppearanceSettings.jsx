import React from 'react'

export default function AppearanceSettings() {
  return (
    <div>
      appearance
    </div>
  )
}
