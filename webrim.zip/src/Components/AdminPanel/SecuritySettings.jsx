import React from 'react'

export default function SecuritySettings() {
  return (
    <div>
      security
    </div>
  )
}
