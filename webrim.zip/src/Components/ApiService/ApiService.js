// const baseurl ='https://web.rimhub.in'
const baseurl ='http://localhost:5000'
export default baseurl